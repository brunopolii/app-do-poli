
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:image_picker/image_picker.dart';
import '../models/models.dart';
import '../services/storage_service.dart';
import '../services/ai_food_service.dart';
import '../widgets/app_card.dart';

class FoodScreen extends StatefulWidget{const FoodScreen({super.key});@override State<FoodScreen> createState()=>_FoodState();}
class _FoodState extends State<FoodScreen>{
 List<Meal> meals=[];final ai=AiFoodService();
 @override void initState(){super.initState();load();}
 Future<void>load()async{meals=(await StorageService.read('meals')).map(Meal.fromJson).toList();if(mounted)setState((){});}
 Future<void>save()=>StorageService.write('meals',meals.map((e)=>e.toJson()).toList());
 Future<void>textAi()async{
  final t=TextEditingController();
  final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Analisar com IA'),content:TextField(controller:t,maxLines:5,decoration:const InputDecoration(hintText:'Ex.: 200g arroz, 150g frango e 100g feijão')),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Analisar'))]));
  if(ok!=true||t.text.trim().isEmpty)return;final r=await ai.estimateText(t.text);if(mounted)showResult(r);
 }
 Future<void>camera()async{
  final p=await ImagePicker().pickImage(source:ImageSource.camera,imageQuality:80);if(p==null)return;
  final r=await ai.estimateImage(p.path);if(mounted)showResult(r);
 }
 void showResult(FoodResult r){showDialog(context:context,builder:(c)=>AlertDialog(title:const Text('Estimativa nutricional'),content:SingleChildScrollView(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[...r.items.map((i)=>ListTile(title:Text(i.name),subtitle:Text('${i.grams.toStringAsFixed(0)}g • ${i.calories.toStringAsFixed(0)} kcal • P ${i.protein.toStringAsFixed(1)}g • C ${i.carbs.toStringAsFixed(1)}g • G ${i.fat.toStringAsFixed(1)}g'))),const Divider(),Text('Total: ${r.calories.toStringAsFixed(0)} kcal',style:const TextStyle(fontWeight:FontWeight.bold)),Text('P ${r.protein.toStringAsFixed(1)}g • C ${r.carbs.toStringAsFixed(1)}g • G ${r.fat.toStringAsFixed(1)}g'),const SizedBox(height:8),Text(r.note,style:const TextStyle(fontSize:12))])),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Fechar')),FilledButton(onPressed:(){setState(()=>meals.add(Meal(id:DateTime.now().microsecondsSinceEpoch.toString(),date:DateFormat('yyyy-MM-dd').format(DateTime.now()),type:'Refeição',food:r.items.map((e)=>e.name).join(', '),calories:r.calories,protein:r.protein,carbs:r.carbs,fat:r.fat,source:'ai')));save();Navigator.pop(c);},child:const Text('Adicionar'))]));}
 @override Widget build(BuildContext c){final d=DateFormat('yyyy-MM-dd').format(DateTime.now());final m=meals.where((e)=>e.date==d);final kcal=m.fold(0.0,(a,b)=>a+b.calories),p=m.fold(0.0,(a,b)=>a+b.protein),carb=m.fold(0.0,(a,b)=>a+b.carbs),fat=m.fold(0.0,(a,b)=>a+b.fat);return SafeArea(child:ListView(padding:const EdgeInsets.all(16),children:[
 Row(children:[Text('Alimentação',style:Theme.of(c).textTheme.headlineMedium),const Spacer(),PopupMenuButton<String>(onSelected:(v){if(v=='text')textAi();if(v=='camera')camera();},itemBuilder:(_)=>const[PopupMenuItem(value:'text',child:Text('🤖 IA por texto')),PopupMenuItem(value:'camera',child:Text('📷 IA pela câmera'))])]),
 AppCard(child:Column(children:[Text('${kcal.toStringAsFixed(0)} kcal',style:const TextStyle(fontSize:30,fontWeight:FontWeight.bold)),Text('Proteína ${p.toStringAsFixed(1)}g • Carbo ${carb.toStringAsFixed(1)}g • Gordura ${fat.toStringAsFixed(1)}g')])),
 ...m.map((e)=>AppCard(child:ListTile(title:Text(e.food),subtitle:Text('${e.calories.toStringAsFixed(0)} kcal • P ${e.protein}g • C ${e.carbs}g • G ${e.fat}g'),trailing:IconButton(icon:const Icon(Icons.delete),onPressed:(){setState(()=>meals.remove(e));save();}))))
]));}
}
