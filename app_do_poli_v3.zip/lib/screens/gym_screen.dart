
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/models.dart';
import '../services/storage_service.dart';
import '../widgets/app_card.dart';

const library=[
['Supino reto','Peito'],['Supino inclinado','Peito'],['Crucifixo máquina','Peito'],['Crossover','Peito'],['Flexão','Peito'],
['Puxada aberta','Costas'],['Puxada fechada','Costas'],['Remada baixa','Costas'],['Remada cavalinho','Costas'],['Remada unilateral','Costas'],['Pullover','Costas'],
['Desenvolvimento','Ombros'],['Elevação lateral','Ombros'],['Elevação frontal','Ombros'],['Crucifixo inverso','Ombros'],
['Rosca direta','Bíceps'],['Rosca alternada','Bíceps'],['Rosca Scott','Bíceps'],['Rosca martelo','Bíceps'],
['Tríceps corda','Tríceps'],['Tríceps testa','Tríceps'],['Tríceps francês','Tríceps'],['Mergulho','Tríceps'],
['Agachamento','Quadríceps'],['Leg press 45','Quadríceps'],['Extensora','Quadríceps'],['Afundo','Quadríceps'],
['Mesa flexora','Posterior'],['Cadeira flexora','Posterior'],['Stiff','Posterior'],['Terra romeno','Posterior'],
['Hip thrust','Glúteos'],['Elevação pélvica','Glúteos'],['Abdução','Glúteos'],
['Panturrilha em pé','Panturrilhas'],['Panturrilha sentado','Panturrilhas'],
['Abdominal supra','Abdômen'],['Abdominal infra','Abdômen'],['Prancha','Abdômen'],['Elevação de pernas','Abdômen'],
];

class GymScreen extends StatefulWidget{const GymScreen({super.key});@override State<GymScreen> createState()=>_GymState();}
class _GymState extends State<GymScreen>{
 List<Workout> workouts=[];
 @override void initState(){super.initState();load();}
 Future<void>load()async{workouts=(await StorageService.read('workouts')).map(Workout.fromJson).toList();if(mounted)setState((){});}
 Future<void>save()=>StorageService.write('workouts',workouts.map((e)=>e.toJson()).toList());
 Future<void>create()async{
  final n=TextEditingController();
  final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Novo treino'),content:TextField(controller:n,decoration:const InputDecoration(labelText:'Nome')),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Criar'))]));
  if(ok!=true||n.text.trim().isEmpty)return;
  final w=Workout(id:DateTime.now().microsecondsSinceEpoch.toString(),name:n.text,date:DateFormat('yyyy-MM-dd').format(DateTime.now()),exercises:[]);
  setState(()=>workouts.add(w));await save();if(mounted)edit(w);
 }
 Future<void>edit(Workout w)async{await showModalBottomSheet(context:context,isScrollControlled:true,builder:(_)=>Editor(w,onChanged:(){save();setState((){});}));}
 Future<void>start(Workout w)async{await Navigator.push(context,MaterialPageRoute(builder:(_)=>Player(w,save)));setState((){});await save();}
 @override Widget build(BuildContext c)=>SafeArea(child:ListView(padding:const EdgeInsets.all(16),children:[
  Row(children:[Text('Academia',style:Theme.of(c).textTheme.headlineMedium?.copyWith(fontWeight:FontWeight.bold)),const Spacer(),FilledButton.icon(onPressed:create,icon:const Icon(Icons.add),label:const Text('Novo treino'))]),
  if(workouts.isEmpty)const AppCard(child:Text('Crie seu primeiro treino.')),
  ...workouts.map((w)=>AppCard(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.fitness_center)),title:Text(w.name),subtitle:Text('${w.exercises.length} exercícios'),onTap:()=>start(w),trailing:PopupMenuButton<String>(onSelected:(v){if(v=='e')edit(w);if(v=='s')start(w);if(v=='d'){setState(()=>workouts.remove(w));save();}},itemBuilder:(_)=>const[PopupMenuItem(value:'s',child:Text('Iniciar treino')),PopupMenuItem(value:'e',child:Text('Editar')),PopupMenuItem(value:'d',child:Text('Excluir'))]))))
 ]));
}
class Editor extends StatefulWidget{final Workout w;final VoidCallback onChanged;const Editor(this.w,{required this.onChanged});@override State<Editor> createState()=>_EditorState();}
class _EditorState extends State<Editor>{
 String group='Todos';
 void add(){
  final list=library.where((e)=>group=='Todos'||e[1]==group).toList();String sel=list.first[0];int sets=3,reps=10;
  showDialog(context:context,builder:(c)=>StatefulBuilder(builder:(c,s)=>AlertDialog(title:const Text('Adicionar exercício'),content:Column(mainAxisSize:MainAxisSize.min,children:[
   DropdownButtonFormField<String>(value:sel,items:list.map((e)=>DropdownMenuItem(value:e[0],child:Text(e[0]))).toList(),onChanged:(v)=>s(()=>sel=v!),decoration:const InputDecoration(labelText:'Exercício')),
   DropdownButtonFormField<int>(value:sets,items:[2,3,4,5].map((e)=>DropdownMenuItem(value:e,child:Text('$e séries'))).toList(),onChanged:(v)=>s(()=>sets=v!),decoration:const InputDecoration(labelText:'Séries')),
   DropdownButtonFormField<int>(value:reps,items:[5,6,8,10,12,15,20].map((e)=>DropdownMenuItem(value:e,child:Text('$e repetições'))).toList(),onChanged:(v)=>s(()=>reps=v!),decoration:const InputDecoration(labelText:'Repetições')),
  ]),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Cancelar')),FilledButton(onPressed:(){final m=list.firstWhere((e)=>e[0]==sel);widget.w.exercises.add(Exercise(id:DateTime.now().microsecondsSinceEpoch.toString(),name:m[0],muscle:m[1],sets:sets,reps:reps));widget.onChanged();setState((){});Navigator.pop(c);},child:const Text('Adicionar'))]));
 }
 @override Widget build(BuildContext c)=>SafeArea(child:Padding(padding:const EdgeInsets.all(16),child:Column(mainAxisSize:MainAxisSize.min,children:[
  Row(children:[Expanded(child:Text('Editar: ${widget.w.name}',style:Theme.of(c).textTheme.titleLarge)),IconButton(onPressed:()=>Navigator.pop(c),icon:const Icon(Icons.close))]),
  DropdownButtonFormField<String>(value:group,items:['Todos','Peito','Costas','Ombros','Bíceps','Tríceps','Quadríceps','Posterior','Glúteos','Panturrilhas','Abdômen'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>group=v!),decoration:const InputDecoration(labelText:'Grupo muscular')),
  Flexible(child:ListView(children:widget.w.exercises.asMap().entries.map((x)=>ListTile(title:Text(x.value.name),subtitle:Text('${x.value.sets} séries × ${x.value.reps}'),trailing:IconButton(icon:const Icon(Icons.delete),onPressed:(){setState(()=>widget.w.exercises.removeAt(x.key));widget.onChanged();})).toList())),
  FilledButton.icon(onPressed:add,icon:const Icon(Icons.add),label:const Text('Adicionar exercício')),
 ])));
}
class Player extends StatefulWidget{final Workout w;final Future<void> Function() save;const Player(this.w,this.save,{super.key});@override State<Player> createState()=>_PlayerState();}
class _PlayerState extends State<Player>{@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:Text(widget.w.name)),body:ListView(padding:const EdgeInsets.all(16),children:[
 const Text('Modo treino',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
 ...widget.w.exercises.map((e)=>AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
  Text(e.name,style:Theme.of(c).textTheme.titleLarge),Text('${e.sets} séries × ${e.reps} repetições'),
  ...List.generate(e.sets,(i)=>Row(children:[Text('Série ${i+1}'),const SizedBox(width:12),Expanded(child:TextFormField(initialValue:e.weights[i]==0?'':e.weights[i].toString(),keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'kg'),onChanged:(v)=>e.weights[i]=double.tryParse(v.replaceAll(',','.'))??0)),Checkbox(value:e.done[i],onChanged:(v)=>setState(()=>e.done[i]=v??false))]))
 ]))),
 FilledButton(onPressed:()async{await widget.save();if(c.mounted)Navigator.pop(c);},child:const Text('Finalizar treino'))
]));}
}
