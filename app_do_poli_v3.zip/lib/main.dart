
import 'package:flutter/material.dart';
import 'screens/gym_screen.dart';
import 'screens/food_screen.dart';

void main()=>runApp(const AppDoPoli());

class AppDoPoli extends StatefulWidget{const AppDoPoli({super.key});@override State<AppDoPoli> createState()=>_AppState();}
class _AppState extends State<AppDoPoli>{
 int index=1;ThemeMode mode=ThemeMode.light;
 @override Widget build(BuildContext c)=>MaterialApp(
  debugShowCheckedModeBanner:false,title:'app do poli',themeMode:mode,
  theme:ThemeData(useMaterial3:true,colorSchemeSeed:const Color(0xFF6750A4)),
  darkTheme:ThemeData(useMaterial3:true,brightness:Brightness.dark,colorSchemeSeed:const Color(0xFF9B82DB)),
  home:Scaffold(
   appBar:AppBar(title:const Text('app do poli',style:TextStyle(fontWeight:FontWeight.bold)),actions:[IconButton(icon:const Icon(Icons.dark_mode),onPressed:()=>setState(()=>mode=mode==ThemeMode.dark?ThemeMode.light:ThemeMode.dark))]),
   body:IndexedStack(index:index,children:[const Placeholder(),const Home(),const GymScreen(),const FoodScreen(),const Placeholder()]),
   bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(v)=>setState(()=>index=v),destinations:const[
    NavigationDestination(icon:Icon(Icons.calendar_month_outlined),label:'Agenda'),
    NavigationDestination(icon:Icon(Icons.home_outlined),label:'Início'),
    NavigationDestination(icon:Icon(Icons.fitness_center_outlined),label:'Academia'),
    NavigationDestination(icon:Icon(Icons.restaurant_outlined),label:'Alimentação'),
    NavigationDestination(icon:Icon(Icons.account_balance_wallet_outlined),label:'Financeiro'),
   ]),
  ),
 );
}
class Home extends StatelessWidget{const Home({super.key});@override Widget build(BuildContext c)=>const Center(child:Text('Bem-vindo ao app do poli V3',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)));}
