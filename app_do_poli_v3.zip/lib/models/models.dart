
class Exercise {
  final String id, name, muscle;
  int sets, reps;
  double rest;
  List<double> weights;
  List<bool> done;
  Exercise({required this.id,required this.name,required this.muscle,required this.sets,required this.reps,this.rest=60,List<double>? weights,List<bool>? done})
      : weights=weights??List.filled(sets,0),done=done??List.filled(sets,false);
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'muscle':muscle,'sets':sets,'reps':reps,'rest':rest,'weights':weights,'done':done};
  factory Exercise.fromJson(Map<String,dynamic> j)=>Exercise(id:j['id'],name:j['name'],muscle:j['muscle']??'',sets:j['sets'],reps:j['reps'],rest:(j['rest']??60).toDouble(),weights:(j['weights'] as List???[]).map((e)=>(e as num).toDouble()).toList(),done:(j['done'] as List???[]).map((e)=>e as bool).toList());
}
class Workout {
  final String id,name,date; List<Exercise> exercises;
  Workout({required this.id,required this.name,required this.date,required this.exercises});
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'date':date,'exercises':exercises.map((e)=>e.toJson()).toList()};
  factory Workout.fromJson(Map<String,dynamic> j)=>Workout(id:j['id'],name:j['name'],date:j['date'],exercises:(j['exercises'] as List???[]).map((e)=>Exercise.fromJson(Map<String,dynamic>.from(e))).toList());
}
class Meal {
  final String id,date,type,food,source; final double calories,protein,carbs,fat;
  Meal({required this.id,required this.date,required this.type,required this.food,required this.calories,required this.protein,required this.carbs,required this.fat,this.source='manual'});
  Map<String,dynamic> toJson()=>{'id':id,'date':date,'type':type,'food':food,'calories':calories,'protein':protein,'carbs':carbs,'fat':fat,'source':source};
  factory Meal.fromJson(Map<String,dynamic> j)=>Meal(id:j['id'],date:j['date'],type:j['type'],food:j['food'],calories:(j['calories'] as num).toDouble(),protein:(j['protein'] as num).toDouble(),carbs:(j['carbs'] as num).toDouble(),fat:(j['fat'] as num).toDouble(),source:j['source']??'manual');
}
class MoneyTransaction {
  final String id,date,description,category; final double amount; final bool income;
  MoneyTransaction({required this.id,required this.date,required this.description,required this.category,required this.amount,required this.income});
  Map<String,dynamic> toJson()=>{'id':id,'date':date,'description':description,'category':category,'amount':amount,'income':income};
  factory MoneyTransaction.fromJson(Map<String,dynamic> j)=>MoneyTransaction(id:j['id'],date:j['date'],description:j['description'],category:j['category']??'Outros',amount:(j['amount'] as num).toDouble(),income:j['income']??false);
}
class AgendaEvent {
  final String id,date,title,description,start,end; final bool recurring;
  AgendaEvent({required this.id,required this.date,required this.title,required this.description,required this.start,required this.end,this.recurring=false});
  Map<String,dynamic> toJson()=>{'id':id,'date':date,'title':title,'description':description,'start':start,'end':end,'recurring':recurring};
  factory AgendaEvent.fromJson(Map<String,dynamic> j)=>AgendaEvent(id:j['id'],date:j['date'],title:j['title'],description:j['description']??'',start:j['start'],end:j['end'],recurring:j['recurring']??false);
}
