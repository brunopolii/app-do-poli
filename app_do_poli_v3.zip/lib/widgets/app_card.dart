
import 'package:flutter/material.dart';
class AppCard extends StatelessWidget {
  final Widget child; const AppCard({super.key,required this.child});
  @override Widget build(BuildContext c)=>Card(elevation:0,child:Padding(padding:const EdgeInsets.all(16),child:child));
}
