
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
class StorageService {
  static Future<List<Map<String,dynamic>>> read(String key) async {
    final p=await SharedPreferences.getInstance();
    return (p.getStringList(key)??[]).map((e)=>Map<String,dynamic>.from(jsonDecode(e))).toList();
  }
  static Future<void> write(String key,List<Map<String,dynamic>> v) async {
    final p=await SharedPreferences.getInstance(); await p.setStringList(key,v.map(jsonEncode).toList());
  }
  static Future<String> getString(String k,[String f='']) async => (await SharedPreferences.getInstance()).getString(k)??f;
  static Future<void> setString(String k,String v) async => (await SharedPreferences.getInstance()).setString(k,v);
}
