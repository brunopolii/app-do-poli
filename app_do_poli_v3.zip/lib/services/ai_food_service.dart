
import 'dart:convert';
import 'package:http/http.dart' as http;

class FoodItem {
  final String name; final double grams,calories,protein,carbs,fat;
  FoodItem({required this.name,required this.grams,required this.calories,required this.protein,required this.carbs,required this.fat});
}
class FoodResult {
  final List<FoodItem> items; final String note;
  FoodResult({required this.items,this.note='Estimativa nutricional. Confira as porções.'});
  double get calories=>items.fold(0,(a,b)=>a+b.calories);
  double get protein=>items.fold(0,(a,b)=>a+b.protein);
  double get carbs=>items.fold(0,(a,b)=>a+b.carbs);
  double get fat=>items.fold(0,(a,b)=>a+b.fat);
}
class AiFoodService {
  final String? endpoint; final String? apiKey;
  AiFoodService({this.endpoint,this.apiKey});
  Future<FoodResult> estimateText(String text) async {
    if(endpoint==null||endpoint!.isEmpty)return _local(text);
    final r=await http.post(Uri.parse(endpoint!),headers:{'Content-Type':'application/json','Authorization':'Bearer ${apiKey??''}'},body:jsonEncode({'text':text}));
    if(r.statusCode<200||r.statusCode>=300)throw Exception('Falha na análise.');
    return _fromJson(jsonDecode(r.body));
  }
  Future<FoodResult> estimateImage(String path) async {
    if(endpoint==null||endpoint!.isEmpty)return FoodResult(items:[FoodItem(name:'Foto da refeição',grams:0,calories:0,protein:0,carbs:0,fat:0)],note:'Câmera pronta. Conecte um backend de IA para reconhecer alimentos na foto.');
    final q=http.MultipartRequest('POST',Uri.parse(endpoint!));
    q.headers['Authorization']='Bearer ${apiKey??''}'; q.files.add(await http.MultipartFile.fromPath('image',path));
    final r=await q.send(); final body=await r.stream.bytesToString();
    if(r.statusCode<200||r.statusCode>=300)throw Exception('Falha na análise da foto.');
    return _fromJson(jsonDecode(body));
  }
  FoodResult _fromJson(Map<String,dynamic> j)=>FoodResult(items:(j['items'] as List).map((x)=>FoodItem(name:x['name'],grams:(x['grams']??0).toDouble(),calories:(x['calories']??0).toDouble(),protein:(x['protein']??0).toDouble(),carbs:(x['carbs']??0).toDouble(),fat:(x['fat']??0).toDouble())).toList(),note:j['note']??'Estimativa.');
  FoodResult _local(String t){
    final s=t.toLowerCase(),a=<FoodItem>[];
    void add(String n,double g,double k,double p,double c,double f)=>a.add(FoodItem(name:n,grams:g,calories:k,protein:p,carbs:c,fat:f));
    if(s.contains('arroz'))add('Arroz',200,260,5,56,.6);
    if(s.contains('feijão')||s.contains('feijao'))add('Feijão',100,76,4.8,13.6,.5);
    if(s.contains('frango'))add('Frango',150,248,46,0,5);
    if(s.contains('ovo'))add('Ovos',100,143,13,1.1,9.5);
    if(s.contains('carne'))add('Carne bovina',150,325,39,0,17);
    if(s.contains('macarrão')||s.contains('macarrao'))add('Macarrão',200,314,11.6,61,1.8);
    if(s.contains('batata'))add('Batata',200,154,4,35,.2);
    if(s.contains('leite'))add('Leite',250,153,8,12,8);
    if(a.isEmpty)add('Não identificado',0,0,0,0,0);
    return FoodResult(items:a,note:'Estimativa local. Para IA real, configure um endpoint seguro.');
  }
}
