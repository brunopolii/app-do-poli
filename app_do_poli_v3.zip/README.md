# app do poli V3

Flutter project for VS Code.

Inclui:
- Início no centro da barra inferior.
- Academia com biblioteca ampliada de exercícios.
- Editor separado do modo de treino.
- Modo treino com séries, repetições, kg por série e conclusão.
- Alimentação com IA por texto e câmera preparada.
- Persistência local.
- Tema claro/escuro.
- Estrutura separada em models, services, screens e widgets.

## Rodar
flutter pub get
flutter create .
flutter run

APK:
flutter build apk --release

## IA
A camada `lib/services/ai_food_service.dart` aceita um endpoint seguro para análise real por texto e imagem. Sem endpoint, existe uma estimativa local demonstrativa. Não coloque uma chave secreta diretamente no APK.
